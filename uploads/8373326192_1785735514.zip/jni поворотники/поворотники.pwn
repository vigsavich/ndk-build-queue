Почему тут не просто `TurnSignalState[vehicleid]` и всё:
если тачка удалится, зареспавнится или этот же `vehicleid` потом получит другая машина, старое состояние может остаться и визуально поворотники будут висеть не на той тачке.
Поэтому тут дополнительно хранится:
- кто включил поворотник
- модель машины в момент включения

За счет этого поворотник сам сбросится если:
- машина удалена
- машина зареспавнена
- игрок вышел с водительского места
- игрок ливнул
- `vehicleid` остался тем же, но машина по факту уже другая

Значения `turnStatus`:
- `1` = левый
- `2` = правый
- `3` = аварийка
- `0` = выключено, это сервер сам шлет во время мигания

Что добавить к переменным:
new TurnSignalState[MAX_VEHICLES];
new bool:TurnSignalBlinkOn[MAX_VEHICLES];
new TurnSignalDriver[MAX_VEHICLES];
new TurnSignalModel[MAX_VEHICLES];
```

Что добавить в `OnGameModeInit`:
SetTimer("UpdateVehicleTurnSignals", 500, true);

for(new i = 0; i < MAX_VEHICLES; i++)
{
    TurnSignalDriver[i] = INVALID_PLAYER_ID;
    TurnSignalModel[i] = 0;
}

Вот сам `OnIncomingRPC`.
Если у вас там уже есть свои `action == 4`, `action == 14` и прочее, просто вставляете внутрь блок с `action == 3`, а не заменяете весь обработчик.

public OnIncomingRPC(playerid, rpcid, BitStream:bs)
{
    if(rpcid != 97) return 1;

    new action;
    if(!BS_ReadUint32(bs, action))
    {
        return 1;
    }

    if(action == 3)
    {
        new vehicleid;
        new turnStatus;

        if(!BS_ReadUint16(bs, vehicleid)) return 1;
        if(!BS_ReadUint8(bs, turnStatus)) return 1;

        if(vehicleid <= 0 || vehicleid >= MAX_VEHICLES) return 1;
        if(!IsValidVehicle(vehicleid)) return 1;
        if(GetPlayerVehicleID(playerid) != vehicleid) return 1;
        if(GetPlayerState(playerid) != PLAYER_STATE_DRIVER) return 1;
        if(turnStatus < 1 || turnStatus > 3) return 1;

        if(TurnSignalState[vehicleid] == turnStatus && TurnSignalDriver[vehicleid] == playerid)
        {
            StopVehicleTurnSignal(vehicleid);
        }
        else
        {
            StopVehicleTurnSignal(vehicleid);
            StartVehicleTurnSignal(playerid, vehicleid, turnStatus);
        }
        return 1;
    }

    return 1;
}

Это добавить в конец мода:

stock SendVehicleTurnLight(playerid, vehicleid, status)
{
    new BitStream:bs = BS_New();
    BS_WriteValue(bs, PR_UINT8, 12);
    BS_WriteValue(bs, PR_UINT16, vehicleid);
    BS_WriteValue(bs, PR_UINT8, status);
    PR_SendPacket(bs, playerid, PR_HIGH_PRIORITY, PR_RELIABLE_ORDERED);
    BS_Delete(bs);
    return 1;
}

stock SendVehicleTurnLightForAll(vehicleid, status)
{
    for(new i = 0; i < MAX_PLAYERS; i++)
    {
        if(!IsPlayerConnected(i)) continue;
        SendVehicleTurnLight(i, vehicleid, status);
    }
    return 1;
}

stock ResetVehicleTurnSignalData(vehicleid)
{
    TurnSignalState[vehicleid] = 0;
    TurnSignalBlinkOn[vehicleid] = false;
    TurnSignalDriver[vehicleid] = INVALID_PLAYER_ID;
    TurnSignalModel[vehicleid] = 0;
    return 1;
}

stock StopVehicleTurnSignal(vehicleid)
{
    if(vehicleid <= 0 || vehicleid >= MAX_VEHICLES) return 1;

    if(IsValidVehicle(vehicleid))
    {
        SendVehicleTurnLightForAll(vehicleid, 0);
    }

    ResetVehicleTurnSignalData(vehicleid);
    return 1;
}

stock StartVehicleTurnSignal(playerid, vehicleid, status)
{
    TurnSignalState[vehicleid] = status;
    TurnSignalBlinkOn[vehicleid] = true;
    TurnSignalDriver[vehicleid] = playerid;
    TurnSignalModel[vehicleid] = GetVehicleModel(vehicleid);
    SendVehicleTurnLightForAll(vehicleid, status);
    return 1;
}

stock StopPlayerVehicleTurnSignal(playerid)
{
    for(new vehicleid = 1; vehicleid < MAX_VEHICLES; vehicleid++)
    {
        if(TurnSignalDriver[vehicleid] != playerid) continue;
        StopVehicleTurnSignal(vehicleid);
    }
    return 1;
}

forward UpdateVehicleTurnSignals();
public UpdateVehicleTurnSignals()
{
    for(new vehicleid = 1; vehicleid < MAX_VEHICLES; vehicleid++)
    {
        if(TurnSignalState[vehicleid] < 1 || TurnSignalState[vehicleid] > 3) continue;

        if(!IsValidVehicle(vehicleid))
        {
            ResetVehicleTurnSignalData(vehicleid);
            continue;
        }

        new driverid = TurnSignalDriver[vehicleid];
        if(driverid == INVALID_PLAYER_ID || !IsPlayerConnected(driverid))
        {
            StopVehicleTurnSignal(vehicleid);
            continue;
        }

        if(GetPlayerState(driverid) != PLAYER_STATE_DRIVER)
        {
            StopVehicleTurnSignal(vehicleid);
            continue;
        }

        if(GetPlayerVehicleID(driverid) != vehicleid)
        {
            StopVehicleTurnSignal(vehicleid);
            continue;
        }

        if(GetVehicleModel(vehicleid) != TurnSignalModel[vehicleid])
        {
            StopVehicleTurnSignal(vehicleid);
            continue;
        }

        if(TurnSignalBlinkOn[vehicleid])
        {
            TurnSignalBlinkOn[vehicleid] = false;
            SendVehicleTurnLightForAll(vehicleid, 0);
        }
        else
        {
            TurnSignalBlinkOn[vehicleid] = true;
            SendVehicleTurnLightForAll(vehicleid, TurnSignalState[vehicleid]);
        }
    }
    return 1;
}

Еще нужно чистить состояние в нужных местах.
Если эти `public` у вас уже есть, не дублируйте их, а просто добавьте внутрь нужную строку.

Для `OnVehicleSpawn`:

public OnVehicleSpawn(vehicleid)
{
    StopVehicleTurnSignal(vehicleid);
    return 1;
}

Для `OnVehicleDeath`:

public OnVehicleDeath(vehicleid, killerid)
{
    StopVehicleTurnSignal(vehicleid);
    return 1;
}

Для `OnPlayerDisconnect`:

public OnPlayerDisconnect(playerid, reason)
{
    StopPlayerVehicleTurnSignal(playerid);
    return 1;
}

Для `OnPlayerStateChange`:

public OnPlayerStateChange(playerid, newstate, oldstate)
{
    if(oldstate == PLAYER_STATE_DRIVER && newstate != PLAYER_STATE_DRIVER)
    {
        StopPlayerVehicleTurnSignal(playerid);
    }
    return 1;
}

Коротко по логике:

- если игрок нажал тот же поворотник второй раз, он выключается
- если нажал другой, старый сбрасывается и включается новый
- мигание идет на сервере таймером раз в 500 мс
- сервер шлет клиенту пакет `12`