new actor_diver[2], sphere_actor[2];

new name_items_diver[5][17] = {"��������", "����", "������� ������", "���������", "����� � ������"};
new price_items[5] = {50000, 75004, 33434, 94753, 100444};
new items_model_diver[5] = {2969, 1025, 19941, 1518, 11735};

#define MAX_DIVER 10
#define MAX_I_DIVER 40

#define I_DIVER_BOX         0    
#define I_DIVER_TIRE        1
#define I_DIVER_GOLD        2
#define I_DIVER_TV          3
#define I_DIVER_BOOT        4

#define br_�   "{D4544B}"
#define CW   "{FFFFFF}"

enum S_DIVER_ORDER
{
    Float:DV_X,
    Float:DV_Y,
    Float:DV_Z,
    DV_P_ID,
}

new Float:order_diver[MAX_DIVER][S_DIVER_ORDER] =
{
    {-1300.630249, 1033.602661, -43.945053, -1}, 
    {-2358.896484, 1102.906127, -40.581607, -1}, 
    {-1711.381713, 1196.425415, -9.541759,  -1}, 
    {-547.580993,  336.653411,  -36.227989, -1}, 
    {1366.407104,  -824.331359,  20.840627, -1}, 
    {1152.262695,  -246.503692, -27.216604, -1}, 
    {1797.563232,  128.639724,  -35.809577, -1}, 
    {1025.245483,  -69.781929,  -43.224620, -1}, 
    {1394.748535,  123.227615,  -33.592060, -1}, 
    {-2864.630859, 232.082199,  -13.864818, -1}
};

new Float:spawn_diver_vehicle[6][5] =
{
    {659.482910,  159.273727, -0.544729, 178.099777, 0.0},
    {639.523742,  158.625823, -0.560347, 178.099777, 0.0},
    {669.388977,  160.232330, -0.553551, 178.099777, 0.0},
    {-2541.923828, 365.270996, -0.560600, 89.943420,  1.0},
    {-2539.665283, 375.239318, -0.562907, 89.943420,  1.0},
    {-2539.389404, 389.337554, -0.544025, 89.943420,  1.0}
};

enum ITEMS_DIVER
{
    I_DV_OBJECT, 
    I_DV_AREA, 
    I_DV_TYPE,
    Text3D:I_DV_3DTEXT,
    Float:I_DV_X,
    Float:I_DV_Y,
    Float:I_DV_Z,
    I_DV_ORDER
}

new items_order[MAX_I_DIVER][ITEMS_DIVER] = 
{
    {-1, -1, -1, Text3D:-1, -1299.736450, 1030.678466, -43.759330, 0},
    {-1, -1, -1, Text3D:-1, -1294.773315, 1030.276000, -44.383892, 0},
    {-1, -1, -1, Text3D:-1, -1291.930664, 1036.798461, -45.649955, 0},
    {-1, -1, -1, Text3D:-1, -1298.802246, 1040.027954, -45.013538, 0},
    {-1, -1, -1, Text3D:-1, -2357.749267, 1101.811523, -46.269500, 1},
    {-1, -1, -1, Text3D:-1, -2356.711669, 1105.708862, -46.339786, 1},
    {-1, -1, -1, Text3D:-1, -2359.528808, 1100.768554, -46.614593, 1},
    {-1, -1, -1, Text3D:-1, -2358.452392, 1095.123168, -46.287437, 1},
    {-1, -1, -1, Text3D:-1, -1711.196533, 1196.271362, -10.546383, 2},
    {-1, -1, -1, Text3D:-1, -1707.007690, 1198.645507, -10.935578, 2},
    {-1, -1, -1, Text3D:-1, -1708.856811, 1203.194824, -9.368476,  2},
    {-1, -1, -1, Text3D:-1, -1717.878295, 1199.776489, -11.360163, 2},
    {-1, -1, -1, Text3D:-1, -549.584899,  335.892456,  -36.853237, 3},
    {-1, -1, -1, Text3D:-1, -551.322692,  340.630706,  -37.462085, 3},
    {-1, -1, -1, Text3D:-1, -547.012023,  344.229461,  -37.120285, 3},
    {-1, -1, -1, Text3D:-1, -540.468627,  338.334197,  -35.029785, 3},
    {-1, -1, -1, Text3D:-1, 1366.101562, -821.534362,  -57.106460, 4},
    {-1, -1, -1, Text3D:-1, 1361.368041, -823.787475,  -57.070491, 4},
    {-1, -1, -1, Text3D:-1, 1362.132568, -831.688232,  -57.016746, 4},
    {-1, -1, -1, Text3D:-1, 1374.770019, -832.624450,  -57.107894, 4},
    {-1, -1, -1, Text3D:-1, 1148.777954, -245.415893,  -27.823001, 5},
    {-1, -1, -1, Text3D:-1, 1151.200317, -239.258209,  -28.728399, 5},
    {-1, -1, -1, Text3D:-1, 1159.555786, -242.678314,  -28.957393, 5},
    {-1, -1, -1, Text3D:-1, 1159.226562, -253.490768,  -27.663639, 5},
    {-1, -1, -1, Text3D:-1, 1798.336791,  129.778839,  -36.258960, 6},
    {-1, -1, -1, Text3D:-1, 1790.974365,  130.863632,  -37.187446, 6},
    {-1, -1, -1, Text3D:-1, 1787.554565,  123.930686,  -37.542568, 6},
    {-1, -1, -1, Text3D:-1, 1790.622924,  117.896026,  -34.462966, 6},
    {-1, -1, -1, Text3D:-1, 1028.397583,  -66.931350,  -43.765480, 7},
    {-1, -1, -1, Text3D:-1, 1022.649902,  -62.609016,  -43.370590, 7},
    {-1, -1, -1, Text3D:-1, 1017.844177,  -64.907760,  -43.576751, 7},
    {-1, -1, -1, Text3D:-1, 1023.193969,  -74.069854,  -44.410453, 7},
    {-1, -1, -1, Text3D:-1, 1395.356079,  122.741455,  -33.808929, 8},
    {-1, -1, -1, Text3D:-1, 1392.876953,  118.109024,  -32.931667, 8},
    {-1, -1, -1, Text3D:-1, 1385.771972,  122.580101,  -31.366134, 8},
    {-1, -1, -1, Text3D:-1, 1391.865234,  129.453933,  -32.073204, 8},
    {-1, -1, -1, Text3D:-1, -2867.856445, 229.483154,  -14.848545, 9},
    {-1, -1, -1, Text3D:-1, -2864.808349, 227.946517,  -14.140148, 9},
    {-1, -1, -1, Text3D:-1, -2862.172607, 232.211746,  -13.310132, 9},
    {-1, -1, -1, Text3D:-1, -2863.333740, 237.873138,  -13.245767, 9}
};

enum STRUCT_DIVER
{
    DV_BOX, 
    DV_GOLD,
    DV_TIRE, 
    DV_TV, 
    DV_BOOT, 
    DV_ID, 
    DV_ID_VEH,
    bool:DIVER_JOOB, 
    bool:DIVER_ORDER
}

new player_diver[MAX_PLAYERS][STRUCT_DIVER];

#define  GetPlayerDiver(%0,%1)      player_diver[%0][%1]
#define  SetPlayerDiver(%0,%1,%2)   player_diver[%0][%1] = %2
#define  AddPlayerDiver(%0,%1,%2,%3) player_diver[%0][%1] %2= %3

// � ������ ����� �������� ��� �������, ���� �� ���
#if !defined ShowNotificationNew
    forward ShowNotificationNew(playerid, type, time, color, icon, const text[], const title[] = "");
#endif

#if !defined SCM
    #define SCM SendClientMessage
#endif

// ================ OnPlayerEnterDynamicArea ================
public OnPlayerEnterDynamicArea(playerid, areaid)
{
    // �������� ���������� � ���� ���������
    for(new i = 0; i < MAX_I_DIVER; i++)
    {
        if(areaid == items_order[i][I_DV_AREA])
        {
            if(items_order[i][I_DV_OBJECT] == -1) 
                return 1;

            if(GetPlayerDiver(playerid, DIVER_JOOB))
            {
                if(items_order[i][I_DV_ORDER] == GetPlayerDiver(playerid, DV_ID))
                {
                    // ��������� ��������� �������
                    return 1;
                }
                else 
                {
                    ShowNotificationNew(playerid, 2, 6, 0, 0, "���� ������� �� � ������ ������.", "");
                    return 0;
                }
            }
            else 
            {
                ShowNotificationNew(playerid, 2, 6, 0, 0, "���������� �� ������ ��������.", "");
                return 0;
            }
        }
    }
    
    // �������� ���������� � ���� �������
    if(areaid == sphere_actor[0] || areaid == sphere_actor[1])
    {
        SetPVarInt(playerid, "shpere_diver", areaid);

        Dialog
        (
            playerid, 2770, DIALOG_STYLE_LIST, 
            ""br_�"������� "CW"| ���� ������", 
            ""br_�"1."CW"����� �����\n"\
            ""br_�"2."CW"����������/��������� � ������\n"\
            ""br_�"3."CW"���������� �����\n"\
            ""br_�"4."CW"������� ��������� ��������", 
            "����������", "�����"
        );
        return 1;
    }
    
    #if defined dv_OnPlayerEnterDynamicArea
        return dv_OnPlayerEnterDynamicArea(playerid, STREAMER_TAG_AREA:areaid);
    #else
        return 0;
    #endif
}

#if defined _ALS_OnPlayerEnterDynamicArea
    #undef OnPlayerEnterDynamicArea
#else
    #define _ALS_OnPlayerEnterDynamicArea
#endif
#define OnPlayerEnterDynamicArea dv_OnPlayerEnterDynamicArea
#if defined dv_OnPlayerEnterDynamicArea
    forward dv_OnPlayerEnterDynamicArea(playerid, STREAMER_TAG_AREA:areaid);
#endif

// ================ OnGameModeInit ================
public OnGameModeInit()
{
    // �������� �������
    CreateActorEx("{D4544B}������� �����", "{FFFFFF}��������� ��� ��������������", 5344, 676.336730, 187.356491, 2.778203, 175.494964);
    CreateActorEx("{D4544B}������� �����", "{FFFFFF}��������� ��� ��������������", 111, -2526.549072, 357.963623, 2.060437, 124.978698);
    
    // �������� ��� ��������������
    sphere_actor[0] = CreateDynamicSphere(676.336730, 187.356491, 2.778203, 2.5, 0, 0);
    sphere_actor[1] = CreateDynamicSphere(-2526.549072, 357.963623, 2.060437, 2.5, 0, 0);
    
    // �������� ��� ���������
    LoadSphereDiver();
    
    #if defined dv_OnGameModeInit
        return dv_OnGameModeInit();
    #else
        return 1;
    #endif
}

#if defined _ALS_OnGameModeInit
    #undef OnGameModeInit
#else
    #define _ALS_OnGameModeInit
#endif
#define OnGameModeInit dv_OnGameModeInit
#if defined dv_OnGameModeInit
    forward dv_OnGameModeInit();
#endif

// ================ OnPlayerDisconnect ================
public OnPlayerDisconnect(playerid, reason)
{
    if(GetPlayerDiver(playerid, DIVER_ORDER))
    {
        RemoveDiverOrder(GetPlayerDiver(playerid, DV_ID));
        if(IsValidVehicle(GetPlayerDiver(playerid, DV_ID_VEH))) 
            DestroyVehicle(GetPlayerDiver(playerid, DV_ID_VEH));
    }
    UnLoadPlayerDiver(playerid);
    
    #if defined dv_OnPlayerDisconnect
        return dv_OnPlayerDisconnect(playerid, reason);
    #else
        return 1;
    #endif
}

#if defined _ALS_OnPlayerDisconnect
    #undef OnPlayerDisconnect
#else
    #define _ALS_OnPlayerDisconnect
#endif
#define OnPlayerDisconnect dv_OnPlayerDisconnect
#if defined dv_OnPlayerDisconnect
    forward dv_OnPlayerDisconnect(playerid, reason);
#endif

// ================ OnPlayerSpawn ================
public OnPlayerSpawn(playerid)
{
    if(GetPlayerDiver(playerid, DV_ID) != -1) 
        LoadPlayerDiver(playerid);

    #if defined dv_OnPlayerSpawn
        return dv_OnPlayerSpawn(playerid);
    #else
        return 1;
    #endif
}

#if defined _ALS_OnPlayerSpawn
    #undef OnPlayerSpawn
#else
    #define _ALS_OnPlayerSpawn
#endif
#define OnPlayerSpawn dv_OnPlayerSpawn
#if defined dv_OnPlayerSpawn
    forward dv_OnPlayerSpawn(playerid);
#endif

// ================ LoadPlayerDiver ================
public LoadPlayerDiver(playerid)
{
    new diver_sql[184];
    new Cache: diver_result;

    mysql_format(mysql, diver_sql, sizeof diver_sql, "SELECT * FROM accounts WHERE id=%d LIMIT 1", GetPlayerAccountID(playerid));
    diver_result = mysql_query(mysql, diver_sql);

    if(cache_num_rows())
    {
        SetPlayerDiver(playerid, DV_BOX, cache_get_field_content_int(0, "box"));
        SetPlayerDiver(playerid, DV_GOLD, cache_get_field_content_int(0, "gold"));
        SetPlayerDiver(playerid, DV_TIRE, cache_get_field_content_int(0, "tire"));
        SetPlayerDiver(playerid, DV_TV, cache_get_field_content_int(0, "television"));
        SetPlayerDiver(playerid, DV_BOOT, cache_get_field_content_int(0, "boot"));
        cache_delete(diver_result);
    }

    SetPlayerDiver(playerid, DV_ID, -1);
    SetPlayerDiver(playerid, DV_ID_VEH, -1);
    
    return 1;
}

// ================ UnLoadPlayerDiver ================
stock UnLoadPlayerDiver(playerid)
{
    UpdatePlayerDatabaseInt(playerid, "boot", GetPlayerDiver(playerid, DV_BOOT));
    UpdatePlayerDatabaseInt(playerid, "television", GetPlayerDiver(playerid, DV_TV));
    UpdatePlayerDatabaseInt(playerid, "gold", GetPlayerDiver(playerid, DV_GOLD));
    UpdatePlayerDatabaseInt(playerid, "tire", GetPlayerDiver(playerid, DV_TIRE));
    UpdatePlayerDatabaseInt(playerid, "box", GetPlayerDiver(playerid, DV_BOX));
    
    SetPlayerDiver(playerid, DV_BOX, 0);
    SetPlayerDiver(playerid, DV_GOLD, 0);
    SetPlayerDiver(playerid, DV_TIRE, 0);
    SetPlayerDiver(playerid, DV_TV, 0);
    SetPlayerDiver(playerid, DV_BOOT, 0);
    SetPlayerDiver(playerid, DV_ID, -1);
    SetPlayerDiver(playerid, DV_ID_VEH, -1);
    SetPlayerDiver(playerid, DIVER_JOOB, false);
    SetPlayerDiver(playerid, DIVER_ORDER, false);

    return 1;
}

// ================ OnPlayerEnterCheckpoint ================
public OnPlayerEnterCheckpoint(playerid)
{
    if((GetPlayerDiver(playerid, DIVER_JOOB) && GetPlayerDiver(playerid, DIVER_ORDER)) || GetPlayerDiver(playerid, DV_ID_VEH) != -1)
    {
        DisablePlayerCheckpoint(playerid);
    }

    #if defined dv_OnPlayerEnterCheckpoint
        return dv_OnPlayerEnterCheckpoint(playerid);
    #else
        return 1;
    #endif
}

#if defined _ALS_OnPlayerEnterCheckpoint
    #undef OnPlayerEnterCheckpoint
#else
    #define _ALS_OnPlayerEnterCheckpoint
#endif
#define OnPlayerEnterCheckpoint dv_OnPlayerEnterCheckpoint
#if defined dv_OnPlayerEnterCheckpoint
    forward dv_OnPlayerEnterCheckpoint(playerid);
#endif

// ================ OnDialogResponse ================
public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == 2770)
    {
        if(response)
        {
            switch(listitem + 1)
            {
                case 1: // ����� �����
                {
                    if(!GetPlayerDiver(playerid, DIVER_JOOB)) 
                        return ShowNotificationNew(playerid, 2, 6, 0, 0, "������� ���������� �� ������.", "");

                    if(GetPlayerDiver(playerid, DIVER_ORDER)) 
                        return ShowNotificationNew(playerid, 2, 6, 0, 0, "� ��� ��� ���� �������� �����.", "");

                    // �������� ��������� ������
                    new availableOrders[MAX_DIVER];
                    new availableCount = 0;
                    
                    for(new d = 0; d < MAX_DIVER; d++)
                    {
                        if(order_diver[d][DV_P_ID] == -1)
                        {
                            availableOrders[availableCount] = d;
                            availableCount++;
                        }
                    }
                    
                    if(availableCount == 0) 
                        return ShowNotificationNew(playerid, 1, 6, 0, 0, "��� ��������� �������, ���������...", "");
                    
                    new selectedOrder = availableOrders[random(availableCount)];
                    
                    order_diver[selectedOrder][DV_P_ID] = playerid;
                    SetPlayerDiver(playerid, DV_ID, selectedOrder);
                    SetPlayerDiver(playerid, DIVER_ORDER, true);
                    LoadOrderDiver(selectedOrder);
                    
                    SetPlayerCheckpoint(playerid, 
                        order_diver[selectedOrder][DV_X], 
                        order_diver[selectedOrder][DV_Y], 
                        order_diver[selectedOrder][DV_Z], 10.0);
                    
                    ShowPlayerGPS(playerid, 
                        order_diver[selectedOrder][DV_X], 
                        order_diver[selectedOrder][DV_Y]);
                }
                
                case 2: // ����������/���������
                {
                    if(GetPlayerDiver(playerid, DIVER_JOOB))
                    {
                        SetPlayerDiver(playerid, DIVER_JOOB, false);
                        SetPlayerSkinInit(playerid);

                        if(GetPlayerDiver(playerid, DIVER_ORDER))
                        {
                            RemoveDiverOrder(GetPlayerDiver(playerid, DV_ID));
                            SetPlayerDiver(playerid, DV_ID, -1);
                            SetPlayerDiver(playerid, DIVER_ORDER, false);
                        }

                        if(GetPlayerDiver(playerid, DV_ID_VEH) != -1)
                        {
                            DestroyVehicle(GetPlayerDiver(playerid, DV_ID_VEH));
                            SetPlayerDiver(playerid, DV_ID_VEH, -1);
                        }
                        
                        ShowNotificationNew(playerid, 2, 6, 0, 0, "�� ��������� � ������ '�������'.", "");
                    }
                    else
                    {
                        SetPlayerSkin(playerid, 5344);
                        SetPlayerDiver(playerid, DIVER_JOOB, true);
                        ShowNotificationNew(playerid, 1, 6, 0, 0, "�� ���������� �� ������ '�������'.", "");
                    }
                }
                
                case 3: // ���������� �����
                {
                    if(!GetPlayerDiver(playerid, DIVER_JOOB)) 
                        return ShowNotificationNew(playerid, 2, 6, 0, 0, "������� ������� �����.", "");

                    if(GetPlayerDiver(playerid, DV_ID_VEH) != -1)
                    {
                        DestroyVehicle(GetPlayerDiver(playerid, DV_ID_VEH));
                        SetPlayerDiver(playerid, DV_ID_VEH, -1);
                        ShowNotificationNew(playerid, 1, 6, 0, 0, "�� ������� �����.", "");
                    }
                    else
                    {
                        if(GetPlayerMoneyEx(playerid) < 200000) 
                            return ShowNotificationNew(playerid, 1, 6, 0, 0, "��� ���������� 200.000 ������.", "");
                        
                        new vehicle;
                        new r;

                        if(GetPVarInt(playerid, "shpere_diver") == sphere_actor[0])
                        {
                            r = random(3);
                            vehicle = CreateVehicle(446, 
                                spawn_diver_vehicle[r][0], 
                                spawn_diver_vehicle[r][1], 
                                spawn_diver_vehicle[r][2], 
                                spawn_diver_vehicle[r][3], 1, 1, -1);
                        }
                        else
                        {
                            r = random(3) + 3;
                            vehicle = CreateVehicle(446, 
                                spawn_diver_vehicle[r][0], 
                                spawn_diver_vehicle[r][1], 
                                spawn_diver_vehicle[r][2], 
                                spawn_diver_vehicle[r][3], 1, 1, -1);
                        }
                        
                        if(vehicle != INVALID_VEHICLE_ID)
                        {
                            SetPlayerDiver(playerid, DV_ID_VEH, vehicle);
                            GivePlayerMoneyEx(playerid, -200000);
                            
                            SetPlayerCheckpoint(playerid, 
                                spawn_diver_vehicle[r][0], 
                                spawn_diver_vehicle[r][1], 
                                spawn_diver_vehicle[r][2], 5.0);
                            
                            ShowPlayerGPS(playerid, 
                                spawn_diver_vehicle[r][0], 
                                spawn_diver_vehicle[r][1]);
                        }
                    }
                }
                
                case 4: // ������� ��������
                {
                    new dialog_text[512];
                    
                    format(dialog_text, sizeof(dialog_text),
                        ""CW"��������\t����������\t��������� ��������\n"\
                        ""CW"��������\t{FFFFFF}%d\t{D7FD00}%d\n"\
                        ""CW"����\t{FFFFFF}%d\t{D7FD00}%d\n"\
                        ""CW"������� ������\t{FFFFFF}%d\t{D7FD00}%d\n"\
                        ""CW"���������\t{FFFFFF}%d\t{D7FD00}%d\n"\
                        ""CW"����� � ������\t{FFFFFF}%d\t{D7FD00}%d",
                        GetPlayerDiver(playerid, DV_BOX), price_items[0],
                        GetPlayerDiver(playerid, DV_TIRE), price_items[1],
                        GetPlayerDiver(playerid, DV_GOLD), price_items[2],
                        GetPlayerDiver(playerid, DV_TV), price_items[3],
                        GetPlayerDiver(playerid, DV_BOOT), price_items[4]);

                    DialogDiver(playerid, 2771, DIALOG_STYLE_TABLIST_HEADERS,
                        ""br_�"������� "CW"| ������� ���������",
                        dialog_text, "�������", "�����");
                }
            }
        }
    }
    else if(dialogid == 2771)
    {
        if(response)
        {
            switch(listitem)
            {
                case 0: // ��������
                {
                    if(GetPlayerDiver(playerid, DV_BOX) <= 0) 
                    {
                        ShowNotificationNew(playerid, 2, 6, 0, 0, "� ��� ��� ��������!", "");
                        return 1;
                    }

                    AddPlayerDiver(playerid, DV_BOX, -, 1);
                    UpdatePlayerDatabaseInt(playerid, "box", GetPlayerDiver(playerid, DV_BOX));
                    GivePlayerMoneyEx(playerid, price_items[0]);
                    ShowNotificationNew(playerid, 1, 6, 0, 0, "�� ������� ��������.", "");
                    
                    // ��������� ������
                    OnDialogResponse(playerid, 2770, 1, 3, "");
                }
                
                case 1: // ����
                {
                    if(GetPlayerDiver(playerid, DV_TIRE) <= 0) 
                    {
                        ShowNotificationNew(playerid, 2, 6, 0, 0, "� ��� ��� ���!", "");
                        return 1;
                    }

                    AddPlayerDiver(playerid, DV_TIRE, -, 1);
                    UpdatePlayerDatabaseInt(playerid, "tire", GetPlayerDiver(playerid, DV_TIRE));
                    GivePlayerMoneyEx(playerid, price_items[1]);
                    ShowNotificationNew(playerid, 1, 6, 0, 0, "�� ������� ����.", "");
                    
                    OnDialogResponse(playerid, 2770, 1, 3, "");
                }
                
                case 2: // ������� ������
                {
                    if(GetPlayerDiver(playerid, DV_GOLD) <= 0) 
                    {
                        ShowNotificationNew(playerid, 2, 6, 0, 0, "� ��� ��� ������� �������!", "");
                        return 1;
                    }

                    AddPlayerDiver(playerid, DV_GOLD, -, 1);
                    UpdatePlayerDatabaseInt(playerid, "gold", GetPlayerDiver(playerid, DV_GOLD));
                    GivePlayerMoneyEx(playerid, price_items[2]);
                    ShowNotificationNew(playerid, 1, 6, 0, 0, "�� ������� ������� ������.", "");
                    
                    OnDialogResponse(playerid, 2770, 1, 3, "");
                }
                
                case 3: // ���������
                {
                    if(GetPlayerDiver(playerid, DV_TV) <= 0) 
                    {
                        ShowNotificationNew(playerid, 2, 6, 0, 0, "� ��� ��� �����������!", "");
                        return 1;
                    }

                    AddPlayerDiver(playerid, DV_TV, -, 1);
                    UpdatePlayerDatabaseInt(playerid, "television", GetPlayerDiver(playerid, DV_TV));
                    GivePlayerMoneyEx(playerid, price_items[3]);
                    ShowNotificationNew(playerid, 1, 6, 0, 0, "�� ������� ���������.", "");
                    
                    OnDialogResponse(playerid, 2770, 1, 3, "");
                }
                
                case 4: // ����� � ������
                {
                    if(GetPlayerDiver(playerid, DV_BOOT) <= 0) 
                    {
                        ShowNotificationNew(playerid, 2, 6, 0, 0, "� ��� ��� ����� � ������!", "");
                        return 1;
                    }

                    AddPlayerDiver(playerid, DV_BOOT, -, 1);
                    UpdatePlayerDatabaseInt(playerid, "boot", GetPlayerDiver(playerid, DV_BOOT));
                    GivePlayerMoneyEx(playerid, price_items[4]);
                    ShowNotificationNew(playerid, 1, 6, 0, 0, "�� ������� ����� � ������.", "");
                    
                    OnDialogResponse(playerid, 2770, 1, 3, "");
                }
            }
        }
        else
        {
            // ������� � ������� ����
            OnDialogResponse(playerid, 2770, 1, 3, "");
        }
    }
    
    #if defined div_OnDialogResponse
        return div_OnDialogResponse(playerid, dialogid, response, listitem, inputtext);
    #else
        return 0;
    #endif
}

#if defined _ALS_OnDialogResponse
    #undef OnDialogResponse
#else
    #define _ALS_OnDialogResponse
#endif
#define OnDialogResponse div_OnDialogResponse
#if defined div_OnDialogResponse
    forward div_OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]);
#endif

// ================ DialogDiver ================
stock DialogDiver(playerid, dialogid, style, title[], text[], button[], button2[])
{
    return ShowPlayerDialog(playerid, dialogid, style, title, text, button, button2);
}

// ================ LoadOrderDiver ================
stock LoadOrderDiver(id)
{
    for(new c = 0; c < MAX_I_DIVER; c++)
    {
        if(items_order[c][I_DV_ORDER] != id) continue;

        new type = random(5);
        new text[64];

        items_order[c][I_DV_TYPE] = type;

        format(text, sizeof(text), "{FFEE00}%s\n{FFFFFF}��������� ��� ��������������", name_items_diver[type]);

        items_order[c][I_DV_OBJECT] = CreateObject(items_model_diver[type], 
            items_order[c][I_DV_X], 
            items_order[c][I_DV_Y], 
            items_order[c][I_DV_Z] - 0.5, 0.0, 0.0, 0.0);
            
        items_order[c][I_DV_3DTEXT] = Create3DTextLabel(text, -1, 
            items_order[c][I_DV_X], 
            items_order[c][I_DV_Y], 
            items_order[c][I_DV_Z], 5.0, 0);
    }
    return 1;
}

// ================ LoadSphereDiver ================
stock LoadSphereDiver()
{
    for(new c = 0; c < MAX_I_DIVER; c++)
    {
        items_order[c][I_DV_AREA] = CreateDynamicSphere(
            items_order[c][I_DV_X], 
            items_order[c][I_DV_Y], 
            items_order[c][I_DV_Z] - 0.7, 3.0);
    }
    return 1;
}

// ================ RemoveDiverOrder ================
stock RemoveDiverOrder(id)
{
    if(id < 0 || id >= MAX_DIVER) return 0;
    
    order_diver[id][DV_P_ID] = -1;
    
    for(new c = 0; c < MAX_I_DIVER; c++)
    {
        if(items_order[c][I_DV_ORDER] == id)
        {
            DestroyDiverItems(c);
        }
    }
    return 1;
}

// ================ IsPlayerInItemsDiver ================
stock IsPlayerInItemsDiver(playerid)
{
    for(new i = 0; i < MAX_I_DIVER; i++)
    {
        if(IsPlayerInDynamicArea(playerid, items_order[i][I_DV_AREA]))
        {
            return i;
        }
    }
    return -1;
}

// ================ Command: takeitems ================
CMD:takeitems(playerid)
{
    new i_id = IsPlayerInItemsDiver(playerid);
    
    if(i_id == -1) 
        return SCM(playerid, -1, "�� ������ ���������� � ��������");
    
    if(items_order[i_id][I_DV_OBJECT] == -1)
        return SCM(playerid, -1, "���� ������� ��� ���������");
    
    if(!GetPlayerDiver(playerid, DIVER_JOOB))
        return ShowNotificationNew(playerid, 2, 6, 0, 0, "���������� �� ������ ��������.", "");
    
    if(items_order[i_id][I_DV_ORDER] != GetPlayerDiver(playerid, DV_ID))
        return ShowNotificationNew(playerid, 2, 6, 0, 0, "���� ������� �� � ������ ������.", "");
    
    new items_count = 0;

    switch(items_order[i_id][I_DV_TYPE])
    {
        case I_DIVER_BOX:
        {
            AddPlayerDiver(playerid, DV_BOX, +, 1);
            UpdatePlayerDatabaseInt(playerid, "box", GetPlayerDiver(playerid, DV_BOX));
            ShowNotificationNew(playerid, 1, 6, 0, 0, "�� ��������� '��������'.", "");
        }
        case I_DIVER_TIRE:
        {   
            AddPlayerDiver(playerid, DV_TIRE, +, 1);
            UpdatePlayerDatabaseInt(playerid, "tire", GetPlayerDiver(playerid, DV_TIRE));
            ShowNotificationNew(playerid, 1, 6, 0, 0, "�� ��������� '����'.", "");
        }
        case I_DIVER_GOLD:
        {
            AddPlayerDiver(playerid, DV_GOLD, +, 1);
            UpdatePlayerDatabaseInt(playerid, "gold", GetPlayerDiver(playerid, DV_GOLD));
            ShowNotificationNew(playerid, 1, 6, 0, 0, "�� ��������� '������ ������'.", "");
        }
        case I_DIVER_TV:
        {
            AddPlayerDiver(playerid, DV_TV, +, 1);
            UpdatePlayerDatabaseInt(playerid, "television", GetPlayerDiver(playerid, DV_TV));
            ShowNotificationNew(playerid, 1, 6, 0, 0, "�� ��������� '���������'.", "");
        }
        case I_DIVER_BOOT:
        {
            AddPlayerDiver(playerid, DV_BOOT, +, 1);
            UpdatePlayerDatabaseInt(playerid, "boot", GetPlayerDiver(playerid, DV_BOOT));
            ShowNotificationNew(playerid, 1, 6, 0, 0, "�� ��������� '����� � ������'.", "");
        }
    }

    DestroyDiverItems(i_id);

    // ���������, ��� �� �������� �������
    for(new i = 0; i < MAX_I_DIVER; i++)
    {
        if(items_order[i][I_DV_ORDER] == GetPlayerDiver(playerid, DV_ID) && items_order[i][I_DV_OBJECT] == -1)
        {
            items_count++;
        }
    }

    // ���� ������� ��� 4 �������� (�� 4 �� �����)
    if(items_count >= 4)
    {
        RemoveDiverOrder(items_order[i_id][I_DV_ORDER]);
        SetPlayerDiver(playerid, DV_ID, -1);
        SetPlayerDiver(playerid, DIVER_ORDER, false);
        ShowNotificationNew(playerid, 1, 6, 0, 0, "�� ������� ��� ��������.", "");

        // ���������� � ���������� �����
        new Float:coord_actor_1[3] = {-2526.549072, 357.963623, 2.060437};
        new Float:coord_actor_2[3] = {676.336730, 187.356491, 2.778203};

        new Float:distance_actor_1 = GetPlayerDistanceFromPoint(playerid, coord_actor_1[0], coord_actor_1[1], coord_actor_1[2]);
        new Float:distance_actor_2 = GetPlayerDistanceFromPoint(playerid, coord_actor_2[0], coord_actor_2[1], coord_actor_2[2]);

        if(distance_actor_1 < distance_actor_2)
            ShowPlayerGPS(playerid, coord_actor_1[0], coord_actor_1[1]);
        else
            ShowPlayerGPS(playerid, coord_actor_2[0], coord_actor_2[1]);
            
        SendClientMessage(playerid, -1, "��������� {D4544B}'������� �����' {FFFFFF}������� �� �����.");
    }

    return 1;
}

// ================ DestroyDiverItems ================
stock DestroyDiverItems(id_items)
{
    if(id_items < 0 || id_items >= MAX_I_DIVER) return 0;
    
    if(IsValidObject(items_order[id_items][I_DV_OBJECT])) 
        DestroyObject(items_order[id_items][I_DV_OBJECT]);
        
    if(IsValidDynamic3DTextLabel(items_order[id_items][I_DV_3DTEXT])) 
        Delete3DTextLabel(items_order[id_items][I_DV_3DTEXT]);

    items_order[id_items][I_DV_TYPE] = -1;
    items_order[id_items][I_DV_OBJECT] = -1;
    items_order[id_items][I_DV_3DTEXT] = Text3D:-1;

    return 1;
}

// ��������������� ������� (���� �� ��� � ����� ����)
#if !defined UpdatePlayerDatabaseInt
    stock UpdatePlayerDatabaseInt(playerid, const fieldname[], value)
    {
        new query[128];
        mysql_format(mysql, query, sizeof(query), "UPDATE accounts SET `%s` = %d WHERE id = %d", 
            fieldname, value, GetPlayerAccountID(playerid));
        mysql_tquery(mysql, query);
        return 1;
    }
#endif

#if !defined GetPlayerAccountID
    stock GetPlayerAccountID(playerid)
    {
        return GetPVarInt(playerid, "account_id");
    }
#endif

#if !defined GivePlayerMoneyEx
    stock GivePlayerMoneyEx(playerid, money)
    {
        return GivePlayerMoney(playerid, money);
    }
#endif

#if !defined GetPlayerMoneyEx
    stock GetPlayerMoneyEx(playerid)
    {
        return GetPlayerMoney(playerid);
    }
#endif

#if !defined ShowPlayerGPS
    stock ShowPlayerGPS(playerid, Float:x, Float:y)
    {
        // ���� ������� ������ GPS
        return 1;
    }
#endif

#if !defined CreateActorEx
    stock CreateActorEx(const title[], const subtitle[], skin, Float:x, Float:y, Float:z, Float:angle)
    {
        // ���� ������� �������� ������
        return 1;
    }
#endif

#if !defined SetPlayerSkinInit
    stock SetPlayerSkinInit(playerid)
    {
        // ���� ������� ��������� �����
        return 1;
    }
#endif