#include "CServerManager.h"

#include <stdint.h>

const char* g_szServerNames[MAX_SERVERS] = {
	"Melon Russia | Humans",
	"Melon Russia | TEST"

};

const CServerInstance::CServerInstanceEncrypted g_sEncryptedAddresses[MAX_SERVERS] = {
	CServerInstance::create("188.127.241.74", 1, 16, 2993, false), // 1
	CServerInstance::create("188.127.241.74", 1, 16, 2993, false) // 2
};