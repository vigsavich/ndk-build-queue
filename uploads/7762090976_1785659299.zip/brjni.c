/*
    BR JNI Sync Core (by TED)
    =========================

    • Один файл: brjni.c
    • 32/64 bit safe (определяет архитектуру по sizeof(void*))
    • Хранит состояние игроков и машин в памяти JNI
    • Умеет:
        - Инициализация / Shutdown
        - Установка локального состояния игрока/машины
        - Построение бинарного снапшота всего мира
        - Применение снапшота (обновление remote-состояния)
        - Получение состояния любого игрока/машины для отрисовки

    Ожидаемый Java-класс:
      package com.ted.brjni;
      public final class BRNative { ... } // см. описание выше

    JNI-имена:
      Java_com_ted_brjni_BRNative_nativeInit
      Java_com_ted_brjni_BRNative_nativeShutdown
      Java_com_ted_brjni_BRNative_nativeGetVersion
      Java_com_ted_brjni_BRNative_nativeGetArchBits
      Java_com_ted_brjni_BRNative_nativeGetLastError
      Java_com_ted_brjni_BRNative_nativeSetLocalPlayer
      Java_com_ted_brjni_BRNative_nativeSetLocalVehicle
      Java_com_ted_brjni_BRNative_nativeBuildSnapshot
      Java_com_ted_brjni_BRNative_nativeApplySnapshot
      Java_com_ted_brjni_BRNative_nativeGetPlayerState
      Java_com_ted_brjni_BRNative_nativeGetVehicleState
*/

#include <jni.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

// ------------------------------------------------------
// ЛОГИ (чтобы в логах не стыдно было)
// ------------------------------------------------------
#ifdef __ANDROID__
    #include <android/log.h>
    #define BR_LOG_TAG "BR_JNI"
    #define BR_LOGI(...) __android_log_print(ANDROID_LOG_INFO,  BR_LOG_TAG, __VA_ARGS__)
    #define BR_LOGE(...) __android_log_print(ANDROID_LOG_ERROR, BR_LOG_TAG, __VA_ARGS__)
#else
    #define BR_LOGI(...) do { fprintf(stdout, __VA_ARGS__); fprintf(stdout, "\n"); } while (0)
    #define BR_LOGE(...) do { fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } while (0)
#endif

// ------------------------------------------------------
// ВНУТРЕННЕЕ СОСТОЯНИЕ
// ------------------------------------------------------

typedef struct PlayerState {
    int   active;
    float x, y, z;
    float rx, ry, rz;
    int   skin;
    int   health;
    int   armor;
    int   weapon;
    int   interior;
    int   vw;
} PlayerState;

typedef struct VehicleState {
    int   active;
    int   ownerPlayerId; // кто в этой машине (или -1)
    int   model;
    float x, y, z;
    float rot;
    int   color1;
    int   color2;
    int   tuningFlags;
} VehicleState;

// Глобальные переменные
static int          g_initialized    = 0;
static int          g_archBits       = 0;
static int          g_lastError      = 0;
static char         g_gameId[64]     = {0};
static char         g_token[128]     = {0};
static char         g_version[32]    = "BR-JNI-SYNC/1.0.0";
static PlayerState* g_players        = NULL;
static VehicleState* g_vehicles      = NULL;
static int          g_maxPlayers     = 0;
static int          g_maxVehicles    = 0;

// ------------------------------------------------------
// УТИЛИТЫ
// ------------------------------------------------------

static void detect_arch_bits(void) {
    if (g_archBits != 0) return;
    if (sizeof(void*) == 8) g_archBits = 64;
    else g_archBits = 32;
    BR_LOGI("[BR_JNI] Architecture detected: %d-bit", g_archBits);
}

static void jstring_to_cstr(JNIEnv* env, jstring js, char* out, size_t outSize) {
    if (!out || outSize == 0) return;
    out[0] = '\0';
    if (!js) return;

    const char* utf = (*env)->GetStringUTFChars(env, js, NULL);
    if (!utf) return;

    strncpy(out, utf, outSize - 1);
    out[outSize - 1] = '\0';

    (*env)->ReleaseStringUTFChars(env, js, utf);
}

static jstring cstr_to_jstring(JNIEnv* env, const char* s) {
    if (!s) s = "";
    return (*env)->NewStringUTF(env, s);
}

// Простейший CRC32 для снапшота
static unsigned int crc32_calc(const unsigned char* data, size_t len) {
    unsigned int crc = 0xFFFFFFFFu;
    for (size_t i = 0; i < len; ++i) {
        crc ^= (unsigned int)data[i];
        for (int j = 0; j < 8; ++j) {
            if (crc & 1u) crc = (crc >> 1) ^ 0xEDB88320u;
            else          crc >>= 1;
        }
    }
    return ~crc;
}

// Безопасная очистка памяти
static void secure_zero(void* ptr, size_t size) {
    if (!ptr || size == 0) return;
    volatile unsigned char* p = (volatile unsigned char*)ptr;
    while (size--) *p++ = 0;
}

// ------------------------------------------------------
// ИНИЦИАЛИЗАЦИЯ/ШТАТ
// ------------------------------------------------------

static void br_reset_state(void) {
    if (g_players) {
        for (int i = 0; i < g_maxPlayers; ++i) {
            g_players[i].active = 0;
        }
    }
    if (g_vehicles) {
        for (int i = 0; i < g_maxVehicles; ++i) {
            g_vehicles[i].active = 0;
        }
    }
    g_lastError = 0;
}

static void br_free_all(void) {
    if (g_players) {
        secure_zero(g_players, sizeof(PlayerState) * g_maxPlayers);
        free(g_players);
        g_players = NULL;
    }
    if (g_vehicles) {
        secure_zero(g_vehicles, sizeof(VehicleState) * g_maxVehicles);
        free(g_vehicles);
        g_vehicles = NULL;
    }
    g_maxPlayers = 0;
    g_maxVehicles = 0;
    g_initialized = 0;
    secure_zero(g_gameId, sizeof(g_gameId));
    secure_zero(g_token, sizeof(g_token));
}

// ------------------------------------------------------
// JNI: nativeInit
// ------------------------------------------------------
JNIEXPORT jboolean JNICALL
Java_com_ted_brjni_BRNative_nativeInit(
        JNIEnv* env,
        jclass clazz,
        jstring jGameId,
        jstring jToken,
        jint jMaxPlayers,
        jint jMaxVehicles) {

    (void)clazz;

    detect_arch_bits();
    br_free_all(); // на всякий случай, если вызывали повторно

    if (jMaxPlayers <= 0 || jMaxVehicles <= 0) {
        g_lastError = -1;
        BR_LOGE("[BR_JNI] nativeInit: invalid sizes (players=%d, vehicles=%d)",
                jMaxPlayers, jMaxVehicles);
        return JNI_FALSE;
    }

    g_maxPlayers  = (int)jMaxPlayers;
    g_maxVehicles = (int)jMaxVehicles;

    g_players  = (PlayerState*)calloc((size_t)g_maxPlayers, sizeof(PlayerState));
    g_vehicles = (VehicleState*)calloc((size_t)g_maxVehicles, sizeof(VehicleState));

    if (!g_players || !g_vehicles) {
        BR_LOGE("[BR_JNI] nativeInit: allocation failed");
        br_free_all();
        g_lastError = -2;
        return JNI_FALSE;
    }

    jstring_to_cstr(env, jGameId, g_gameId, sizeof(g_gameId));
    jstring_to_cstr(env, jToken,  g_token,  sizeof(g_token));

    br_reset_state();
    g_initialized = 1;

    BR_LOGI("[BR_JNI] Initialized: gameId='%s', token='%s', players=%d, vehicles=%d",
            g_gameId, g_token, g_maxPlayers, g_maxVehicles);

    return JNI_TRUE;
}

// ------------------------------------------------------
// JNI: nativeShutdown
// ------------------------------------------------------
JNIEXPORT void JNICALL
Java_com_ted_brjni_BRNative_nativeShutdown(
        JNIEnv* env,
        jclass clazz) {
    (void)env;
    (void)clazz;
    BR_LOGI("[BR_JNI] nativeShutdown()");
    br_free_all();
}

// ------------------------------------------------------
// JNI: nativeGetVersion
// ------------------------------------------------------
JNIEXPORT jstring JNICALL
Java_com_ted_brjni_BRNative_nativeGetVersion(
        JNIEnv* env,
        jclass clazz) {
    (void)clazz;
    return cstr_to_jstring(env, g_version);
}

// ------------------------------------------------------
// JNI: nativeGetArchBits
// ------------------------------------------------------
JNIEXPORT jint JNICALL
Java_com_ted_brjni_BRNative_nativeGetArchBits(
        JNIEnv* env,
        jclass clazz) {
    (void)env;
    (void)clazz;
    detect_arch_bits();
    return (jint)g_archBits;
}

// ------------------------------------------------------
// JNI: nativeGetLastError
// ------------------------------------------------------
JNIEXPORT jint JNICALL
Java_com_ted_brjni_BRNative_nativeGetLastError(
        JNIEnv* env,
        jclass clazz) {
    (void)env;
    (void)clazz;
    return (jint)g_lastError;
}

// ------------------------------------------------------
// ВНУТРЕННИЕ СЕТТЕРЫ
// ------------------------------------------------------
static int br_check_initialized(void) {
    if (!g_initialized) {
        g_lastError = -100;
        return 0;
    }
    return 1;
}

// ------------------------------------------------------
// JNI: nativeSetLocalPlayer
// ------------------------------------------------------
JNIEXPORT jint JNICALL
Java_com_ted_brjni_BRNative_nativeSetLocalPlayer(
        JNIEnv* env,
        jclass clazz,
        jint jPlayerId,
        jfloat jX, jfloat jY, jfloat jZ,
        jfloat jRX, jfloat jRY, jfloat jRZ,
        jint jSkin,
        jint jHealth,
        jint jArmor,
        jint jWeapon,
        jint jInterior,
        jint jVW) {

    (void)env;
    (void)clazz;

    if (!br_check_initialized()) return -1;

    int id = (int)jPlayerId;
    if (id < 0 || id >= g_maxPlayers) {
        g_lastError = -2;
        return -2;
    }

    PlayerState* p = &g_players[id];
    p->active   = 1;
    p->x        = jX;
    p->y        = jY;
    p->z        = jZ;
    p->rx       = jRX;
    p->ry       = jRY;
    p->rz       = jRZ;
    p->skin     = (int)jSkin;
    p->health   = (int)jHealth;
    p->armor    = (int)jArmor;
    p->weapon   = (int)jWeapon;
    p->interior = (int)jInterior;
    p->vw       = (int)jVW;

    return 0;
}

// ------------------------------------------------------
// JNI: nativeSetLocalVehicle
// ------------------------------------------------------
JNIEXPORT jint JNICALL
Java_com_ted_brjni_BRNative_nativeSetLocalVehicle(
        JNIEnv* env,
        jclass clazz,
        jint jPlayerId,
        jint jVehicleId,
        jint jModel,
        jfloat jX, jfloat jY, jfloat jZ,
        jfloat jRot,
        jint jColor1,
        jint jColor2,
        jint jTuningFlags) {

    (void)env;
    (void)clazz;

    if (!br_check_initialized()) return -1;

    int pid = (int)jPlayerId;
    int vid = (int)jVehicleId;

    if (pid < 0 || pid >= g_maxPlayers) {
        g_lastError = -2;
        return -2;
    }
    if (vid < 0 || vid >= g_maxVehicles) {
        g_lastError = -3;
        return -3;
    }

    VehicleState* v = &g_vehicles[vid];
    v->active         = 1;
    v->ownerPlayerId  = pid;
    v->model          = (int)jModel;
    v->x              = jX;
    v->y              = jY;
    v->z              = jZ;
    v->rot            = jRot;
    v->color1         = (int)jColor1;
    v->color2         = (int)jColor2;
    v->tuningFlags    = (int)jTuningFlags;

    return 0;
}

// ------------------------------------------------------
// СНАПШОТ ФОРМАТ (байтовый протокол внутрь/наружу)
// ------------------------------------------------------
/*
    Формат бинарного снапшота:
    [0..3]   - сигнатура 'B','R','J','S' (BRJN Snapshot)
    [4..7]   - версия формата (int)
    [8..11]  - число игроков (int)
    [12..15] - число машин (int)
    [16..19] - зарезервировано (int, 0)
    [20..23] - crc32 от payload (int)

    Далее payload:

    Для каждого игрока (i от 0 до countPlayers-1):

      int   id
      int   active
      float x,y,z
      float rx,ry,rz
      int   skin
      int   health
      int   armor
      int   weapon
      int   interior
      int   vw

    Для каждой машины (j от 0 до countVehicles-1):

      int   id
      int   active
      int   ownerPlayerId
      int   model
      float x,y,z
      float rot
      int   color1
      int   color2
      int   tuningFlags
*/

#define BR_SNAP_SIGNATURE 0x42524A53u  /* 'B''R''J''S' */
#define BR_SNAP_VERSION   1

// Подсчитает размер needed payload
static size_t br_calc_payload_size(int pCount, int vCount) {
    size_t ps = 0;
    // player:
    // id, active, skin, health, armor, weapon, interior, vw = 8 * 4 байта = 32
    // x,y,z,rx,ry,rz = 6 * 4 байта = 24
    // итого 56
    ps += (size_t)pCount * (size_t)56;

    // vehicle:
    // id, active, ownerId, model, color1, color2, tuningFlags = 7 * 4 = 28
    // x,y,z,rot = 4 * 4 = 16
    // итого 44
    ps += (size_t)vCount * (size_t)44;

    return ps;
}

// ------------------------------------------------------
// JNI: nativeBuildSnapshot
// ------------------------------------------------------
JNIEXPORT jint JNICALL
Java_com_ted_brjni_BRNative_nativeBuildSnapshot(
        JNIEnv* env,
        jclass clazz,
        jbyteArray jOutBuffer) {

    (void)clazz;

    if (!br_check_initialized()) return -1;

    if (jOutBuffer == NULL) {
        g_lastError = -10;
        return -10;
    }

    jsize bufLen = (*env)->GetArrayLength(env, jOutBuffer);
    if (bufLen <= 24) {
        g_lastError = -11;
        return -11;
    }

    // Считаем количество активных игроков/машин
    int pCount = 0;
    int vCount = 0;
    for (int i = 0; i < g_maxPlayers; ++i) {
        if (g_players[i].active) pCount++;
    }
    for (int i = 0; i < g_maxVehicles; ++i) {
        if (g_vehicles[i].active) vCount++;
    }

    size_t payloadSize = br_calc_payload_size(pCount, vCount);
    size_t totalSize   = 24 + payloadSize;

    if ((size_t)bufLen < totalSize) {
        g_lastError = -12;
        return -12;
    }

    // Выделяем временный буфер
    unsigned char* buffer = (unsigned char*)malloc(totalSize);
    if (!buffer) {
        g_lastError = -13;
        return -13;
    }
    memset(buffer, 0, totalSize);

    unsigned char* p = buffer;

    // Заголовок
    // сигнатура
    *(unsigned int*)(p + 0)  = BR_SNAP_SIGNATURE;
    *(unsigned int*)(p + 4)  = BR_SNAP_VERSION;
    *(unsigned int*)(p + 8)  = (unsigned int)pCount;
    *(unsigned int*)(p + 12) = (unsigned int)vCount;
    *(unsigned int*)(p + 16) = 0; // reserved
    // crc позже
    // payload начнётся с offset 24
    p += 24;

    // Плееры
    for (int i = 0; i < g_maxPlayers; ++i) {
        if (!g_players[i].active) continue;
        PlayerState* ps = &g_players[i];

        *(int*)(p + 0)  = i;             // id
        *(int*)(p + 4)  = ps->active;
        *(float*)(p + 8)  = ps->x;
        *(float*)(p + 12) = ps->y;
        *(float*)(p + 16) = ps->z;
        *(float*)(p + 20) = ps->rx;
        *(float*)(p + 24) = ps->ry;
        *(float*)(p + 28) = ps->rz;
        *(int*)(p + 32)   = ps->skin;
        *(int*)(p + 36)   = ps->health;
        *(int*)(p + 40)   = ps->armor;
        *(int*)(p + 44)   = ps->weapon;
        *(int*)(p + 48)   = ps->interior;
        *(int*)(p + 52)   = ps->vw;

        p += 56;
    }

    // Машины
    for (int i = 0; i < g_maxVehicles; ++i) {
        if (!g_vehicles[i].active) continue;
        VehicleState* vs = &g_vehicles[i];

        *(int*)(p + 0)  = i;               // id
        *(int*)(p + 4)  = vs->active;
        *(int*)(p + 8)  = vs->ownerPlayerId;
        *(int*)(p + 12) = vs->model;
        *(float*)(p + 16) = vs->x;
        *(float*)(p + 20) = vs->y;
        *(float*)(p + 24) = vs->z;
        *(float*)(p + 28) = vs->rot;
        *(int*)(p + 32) = vs->color1;
        *(int*)(p + 36) = vs->color2;
        *(int*)(p + 40) = vs->tuningFlags;

        p += 44;
    }

    // CRC по payload
    size_t payloadOffset = 24;
    unsigned int crc = crc32_calc(buffer + payloadOffset, payloadSize);
    *(unsigned int*)(buffer + 20) = crc;

    // Копируем в Java-буфер
    (*env)->SetByteArrayRegion(env, jOutBuffer, 0, (jsize)totalSize, (jbyte*)buffer);

    free(buffer);
    g_lastError = 0;
    return (jint)totalSize; // возвращаем фактический размер снапшота
}

// ------------------------------------------------------
// JNI: nativeApplySnapshot
// ------------------------------------------------------
JNIEXPORT jint JNICALL
Java_com_ted_brjni_BRNative_nativeApplySnapshot(
        JNIEnv* env,
        jclass clazz,
        jbyteArray jInBuffer,
        jint jLength) {

    (void)clazz;

    if (!br_check_initialized()) return -1;

    if (jInBuffer == NULL || jLength <= 24) {
        g_lastError = -20;
        return -20;
    }

    jsize bufLen = (*env)->GetArrayLength(env, jInBuffer);
    if (bufLen < jLength) {
        g_lastError = -21;
        return -21;
    }

    unsigned char* buffer = (unsigned char*)malloc((size_t)jLength);
    if (!buffer) {
        g_lastError = -22;
        return -22;
    }

    (*env)->GetByteArrayRegion(env, jInBuffer, 0, jLength, (jbyte*)buffer);

    // Проверяем заголовок
    if (*(unsigned int*)(buffer + 0) != BR_SNAP_SIGNATURE) {
        free(buffer);
        g_lastError = -23;
        return -23;
    }

    unsigned int version = *(unsigned int*)(buffer + 4);
    if (version != BR_SNAP_VERSION) {
        free(buffer);
        g_lastError = -24;
        return -24;
    }

    int pCount = (int)(*(unsigned int*)(buffer + 8));
    int vCount = (int)(*(unsigned int*)(buffer + 12));
    unsigned int recvCrc = *(unsigned int*)(buffer + 20);

    size_t payloadSize = br_calc_payload_size(pCount, vCount);
    size_t totalSize   = 24 + payloadSize;

    if ((size_t)jLength < totalSize) {
        free(buffer);
        g_lastError = -25;
        return -25;
    }

    unsigned int calcCrc = crc32_calc(buffer + 24, payloadSize);
    if (calcCrc != recvCrc) {
        free(buffer);
        g_lastError = -26;
        return -26;
    }

    // Применяем к локальному состоянию "remote"-слой.
    // Для простоты: полностью сбрасываем и заполняем только теми, кто в снапшоте.
    for (int i = 0; i < g_maxPlayers; ++i) {
        g_players[i].active = 0;
    }
    for (int i = 0; i < g_maxVehicles; ++i) {
        g_vehicles[i].active = 0;
    }

    unsigned char* p = buffer + 24;

    // Игроки
    for (int idx = 0; idx < pCount; ++idx) {
        int id = *(int*)(p + 0);
        int active = *(int*)(p + 4);

        if (id >= 0 && id < g_maxPlayers && active) {
            PlayerState* ps = &g_players[id];
            ps->active   = active;
            ps->x        = *(float*)(p + 8);
            ps->y        = *(float*)(p + 12);
            ps->z        = *(float*)(p + 16);
            ps->rx       = *(float*)(p + 20);
            ps->ry       = *(float*)(p + 24);
            ps->rz       = *(float*)(p + 28);
            ps->skin     = *(int*)(p + 32);
            ps->health   = *(int*)(p + 36);
            ps->armor    = *(int*)(p + 40);
            ps->weapon   = *(int*)(p + 44);
            ps->interior = *(int*)(p + 48);
            ps->vw       = *(int*)(p + 52);
        }
        p += 56;
    }

    // Машины
    for (int idx = 0; idx < vCount; ++idx) {
        int id     = *(int*)(p + 0);
        int active = *(int*)(p + 4);

        if (id >= 0 && id < g_maxVehicles && active) {
            VehicleState* vs = &g_vehicles[id];
            vs->active        = active;
            vs->ownerPlayerId = *(int*)(p + 8);
            vs->model         = *(int*)(p + 12);
            vs->x             = *(float*)(p + 16);
            vs->y             = *(float*)(p + 20);
            vs->z             = *(float*)(p + 24);
            vs->rot           = *(float*)(p + 28);
            vs->color1        = *(int*)(p + 32);
            vs->color2        = *(int*)(p + 36);
            vs->tuningFlags   = *(int*)(p + 40);
        }
        p += 44;
    }

    free(buffer);
    g_lastError = 0;
    return 0;
}

// ------------------------------------------------------
// JNI: nativeGetPlayerState
// ------------------------------------------------------
JNIEXPORT jint JNICALL
Java_com_ted_brjni_BRNative_nativeGetPlayerState(
        JNIEnv* env,
        jclass clazz,
        jint jPlayerId,
        jfloatArray jPosRotOut,
        jintArray jIntDataOut) {

    (void)clazz;

    if (!br_check_initialized()) return -1;

    int id = (int)jPlayerId;
    if (id < 0 || id >= g_maxPlayers) {
        g_lastError = -30;
        return -30;
    }

    PlayerState* ps = &g_players[id];
    if (!ps->active) {
        g_lastError = 1; // неактивный
        return 1;
    }

    if (jPosRotOut == NULL || jIntDataOut == NULL) {
        g_lastError = -31;
        return -31;
    }

    if ((*env)->GetArrayLength(env, jPosRotOut) < 6 ||
        (*env)->GetArrayLength(env, jIntDataOut) < 6) {
        g_lastError = -32;
        return -32;
    }

    jfloat tmpF[6];
    jint   tmpI[6];

    tmpF[0] = ps->x;
    tmpF[1] = ps->y;
    tmpF[2] = ps->z;
    tmpF[3] = ps->rx;
    tmpF[4] = ps->ry;
    tmpF[5] = ps->rz;

    tmpI[0] = ps->skin;
    tmpI[1] = ps->health;
    tmpI[2] = ps->armor;
    tmpI[3] = ps->weapon;
    tmpI[4] = ps->interior;
    tmpI[5] = ps->vw;

    (*env)->SetFloatArrayRegion(env, jPosRotOut, 0, 6, tmpF);
    (*env)->SetIntArrayRegion(env,   jIntDataOut, 0, 6, tmpI);

    g_lastError = 0;
    return 0;
}

// ------------------------------------------------------
// JNI: nativeGetVehicleState
// ------------------------------------------------------
JNIEXPORT jint JNICALL
Java_com_ted_brjni_BRNative_nativeGetVehicleState(
        JNIEnv* env,
        jclass clazz,
        jint jVehicleId,
        jfloatArray jPosRotOut,
        jintArray jIntDataOut) {

    (void)clazz;

    if (!br_check_initialized()) return -1;

    int id = (int)jVehicleId;
    if (id < 0 || id >= g_maxVehicles) {
        g_lastError = -40;
        return -40;
    }

    VehicleState* vs = &g_vehicles[id];
    if (!vs->active) {
        g_lastError = 1; // неактив
        return 1;
    }

    if (jPosRotOut == NULL || jIntDataOut == NULL) {
        g_lastError = -41;
        return -41;
    }

    if ((*env)->GetArrayLength(env, jPosRotOut) < 4 ||
        (*env)->GetArrayLength(env, jIntDataOut) < 4) {
        g_lastError = -42;
        return -42;
    }

    jfloat tmpF[4];
    jint   tmpI[4];

    tmpF[0] = vs->x;
    tmpF[1] = vs->y;
    tmpF[2] = vs->z;
    tmpF[3] = vs->rot;

    tmpI[0] = vs->model;
    tmpI[1] = vs->color1;
    tmpI[2] = vs->color2;
    tmpI[3] = vs->tuningFlags;

    (*env)->SetFloatArrayRegion(env, jPosRotOut, 0, 4, tmpF);
    (*env)->SetIntArrayRegion(env,   jIntDataOut, 0, 4, tmpI);

    g_lastError = 0;
    return 0;
}